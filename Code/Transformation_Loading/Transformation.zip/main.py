

from src import test_spark as t





config_filename = '1650931200.json'
bucket_name = 'aoe2spark'
t.transform(bucket_name, config_filename)